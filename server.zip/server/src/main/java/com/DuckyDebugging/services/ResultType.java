package com.DuckyDebugging.services;

public enum ResultType {
    SUCCESS,
    INVALID,
    NOT_FOUND
}
