import React, {Fragment} from 'react'
import {Button} from 'react-bootstrap'

export default function Buttons() {
    return (
        <Fragment>
            <Button variant="primary">
                Click me
            </Button>
        </Fragment>
    )
}
